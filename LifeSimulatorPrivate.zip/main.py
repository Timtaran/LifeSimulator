from src import discord_admin_id, discord_config, vk_config, bps
from loguru import logger
import asyncio
while True:
	dov = input('Что вы хотите запустить? (2-site, 1-discord, 0-vk)')
	try:
		if int(dov) == 0:
			from vkbottle import Bot
			bot = Bot(vk_config)
			for bp in bps:
				bp.load(bot)
			bot.run_forever()
		elif int(dov) == 2:
			from aiohttp import web
			from src.site.app import app
			web.run_app(app)
		elif int(dov) == 1:
			import discord, os
			from discord.ext import commands

			client = commands.Bot(command_prefix='')
			client.remove_command("help")


			@client.command(aliases=['!load'])
			async def load_cog(ctx, extension):
				if ctx.author.id == discord_admin_id:
					try:
						client.load_extension(f"src.discord.{extension}")
						await ctx.send(f"Cog {extension} is loaded...")
					except Exception as ex:
						await ctx.send(ex)
				else:
					await ctx.send("._?")


			@client.command(aliases=['!unload'])
			async def unload_cog(ctx, extension):
				if ctx.author.id == discord_admin_id:
					try:
						client.unload_extension(f"src.discord.{extension}")
						await ctx.send(f"Cog {extension} is unloaded...")
					except Exception as ex:
						await ctx.send(ex)
				else:
					await ctx.send("._?")


			@client.command(aliases=['!reload'])
			async def reload_cog(ctx, extension):
				if ctx.author.id == discord_admin_id:
					try:
						client.unload_extension(f"src.discord.{extension}")
						client.load_extension(f"src.discord.{extension}")
						await ctx.send(f"Cog {extension} is reloaded...")
					except Exception as ex:
						await ctx.send(ex)
				else:
					await ctx.send("._?")


			@client.command(aliases=['!status', 'status', 'статус'])
			async def status_change(ctx, f1, f2):
				if ctx.author.id == discord_admin_id:
					try:
						if f1 == '0':
							await client.change_presence(activity=discord.Game(name=f2))
						elif f1 == '1':
							await client.change_presence(activity=discord.Activity(type=discord.ActivityType.listening,
																				   name=f2))
						elif f1 == '2':
							await client.change_presence(activity=discord.Streaming(name=f2,
																					url='https://www.twitch.tv/timtaran'))
						elif f1 == '3':
							await bot.change_presence(
								activity=discord.Activity(type=discord.ActivityType.watching, name=f2))
						else:
							await ctx.send("ну как бы ладно")
					except Exception as ex:
						await ctx.send(ex)
				else:
					await ctx.send("._?")


			@client.event
			async def on_ready():
				await client.change_presence(activity=discord.Game(name="TeStInG"))
				#await client.change_presence(activity=discord.Activity(type=discord.ActivityType.listening, name="туц ту ту туц туц туц ту ту туц ту ту туц ту ту ту ту ту ту ту ту ту..."))
				#await client.change_presence(activity=discord.Streaming(name="Стрима больше нет!", url='https://www.twitch.tv/timtaran'))
			for filename in os.listdir("src/discord"):
				try:
					if filename.endswith(".py"):
						client.load_extension(f"src.discord.{filename.replace('.py', '')}")
				except Exception as ex:
					print(ex)
			client.run(discord_config)
		else:
			pass
	except Exception as ex:
		print(ex)