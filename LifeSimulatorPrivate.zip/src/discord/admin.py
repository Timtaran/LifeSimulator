from src import for_bd
session, User = for_bd.session, for_bd.User
from src.vk.help import where_is, ban
import discord
from discord.ext import commands
class get(commands.Cog):
	def __init__(self, client):
		self.client = client
	@commands.Cog.listener()
	async def on_ready(self):
		print('?')
	@commands.command(aliases=['set', '!set'])
	async def set_user(self, ctx, id, filter, *args):
		if ctx.message.author.id == 440408198168576001:
			text = ''
			for i in args:
				text += i
				text += ' '
			#user = session.query(User).filter_by(id=int(id)).update({f'{filter}': f'{text}'})

	@commands.command(aliases=['get', 'инфо', 'информация', 'info', '!get', '!инфо', '!информация', '!info'])
	async def get_user_info(self, ctx, filter, filter2, *args):
		if ctx.message.channel.id == 738083814009471077:
			if filter.lower()=='id':
				user = session.query(User).filter_by(id=int(filter2)).first()
				if user == None:
					await ctx.send('Пользователя не существует')
				await ctx.send(
					f"Данные о пользователе {user.nick}:\nID - {user.id}\nUID - {user.uid}\nBalance - {user.balance}\nЛокация - {where_is[user.where_is]}\nБан {ban[str(user.ban)]}\nFullName - {user.FL_name}")
			elif filter.lower()=='uid':
				user = session.query(User).filter_by(uid=int(filter2)).first()
				await ctx.send(f"Данные о пользователе {user.nick}:\nID - {user.id}\nUID - {user.uid}\nBalance - {user.balance}\nЛокация - {where_is[user.where_is]}\nБан {ban[str(user.ban)]}\nFullName - {user.FL_name}")
			else:
				await ctx.send('Данный фильтр запрещен или не найден.')

def setup(client):
	client.add_cog(get(client))