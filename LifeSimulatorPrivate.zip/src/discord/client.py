from discord.ext import commands

client = commands.Bot(command_prefix='')
def setup(c):
	pass