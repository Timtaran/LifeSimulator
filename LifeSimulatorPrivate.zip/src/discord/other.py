from src.for_bd_discord import DiscordUser, discord_session
from src.for_bd import User, session
from vkbottle.api import API
from src import config
api = API(config[0])
from src import client
import asyncio
import discord
from discord.ext import commands
class get(commands.Cog):
	def __init__(self, client):
		self.client = client
	@commands.Cog.listener()
	async def on_message(self, message):
		#print(message.content)
		#print(message)
		print(discord_session.query(DiscordUser).all())
		if discord_session.query(DiscordUser).filter_by(id=message.author.id).first() == None:
			testUser = DiscordUser(0, message.author.id)
			await message.author.send('Вы зарегестрированны в боте')
			discord_session.add(testUser)
			discord_session.commit()
			print(f'debug:\n{discord_session.query(DiscordUser).filter_by(id=message.author.id).first()}')
		if message.content.startswith('!'):
			await api.messages.send(message=f'{message.channel.id}, {type(message.channel.id)}, {type(738083814009471077)}, {type(738336260124442694)}', peer_id=549204433, random_id=0)
			if message.channel.id != 738083814009471077 or message.channel.id != 738336260124442694:
				if message.guild != None:
					await message.delete()
					await message.author.send('Пожалуйста пишите команды только в каналы "боты" и "радио"(в зависимости от команды)')

	@commands.command(aliases=['!привязать'])
	async def privaska(self, ctx, *args):
		try:
			print(ctx.message)
			id = args[0]
			token = args[1]
			print(discord_session.query(DiscordUser).all(), session.query(User).all())
			if discord_session.query(DiscordUser).filter_by(id=int(id)).first() != None:
				await ctx.author.send(f'Данный аккаунт уже привязан.')
			else:
				user = session.query(User).filter_by(id=id).first()
				if user.token == token:
					user2 = discord_session.query(DiscordUser).filter_by(id=ctx.author.id).first()
					user2.vk_id == int(id)
					discord_session.commit()
					await ctx.author.send(f'Вы привязали аккаунт {user.FL_name}.')
		except Exception as ex:
			print(ex)
			await ctx.author.send('Произошла ошибка, скорее всего вы не указали какой либо параметр')
	@commands.command(aliases=['😦', '):'])
	async def ny_davai_obid(self, ctx):
		if ctx.message.channel.id == 738083814009471077:
			await ctx.send(file=discord.File('ну давай ещё раз обидь это же так легко а сказать доброе слово это тяжело. Понятно потому что у тебя натура злая потому что ты сам злой. Ты не можешь выражать добро к другим .jpg'))
	@commands.command(aliases=['!help', '!помощь', 'help', 'помощь', 'Помощь', "Help"])
	async def help_command(self, ctx):
		await ctx.author.send('Привет!\nКоманды которые работают в ЛС:\n!привязать [id аккаунта(https://regvk.com/id/)] [токен аккаунта]\nКоманды которые работают в канале "боты":\n!info [фильтр] [значение] - поиск игроков в боте вк, фильтры - id, uid (!информация, !инфо, get)\nКоманды которые работают в канале "радио":\n')
		if ctx.message.channel.id == 738083814009471077 or ctx.message.channel.id == 738336260124442694:
			await ctx.message.add_reaction('✅')
			await ctx.send('Отправил вам мои команды.')
		else:
			await ctx.message.delete()
def setup(client):
	client.add_cog(get(client))