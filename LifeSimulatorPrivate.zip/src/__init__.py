from .discord.client import client
from src.vk.blueprints import bps
from .config import config
vk_config = [config[0], config[1], config[2], config[3], config[4]]
discord_config = config[5]
discord_admin_id = 440408198168576001