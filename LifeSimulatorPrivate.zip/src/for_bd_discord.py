from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session

discord_engine = create_engine('postgresql://postgres:%||%\_/0296itTvG@127.0.0.1:5432/discord', echo=True)
DiscordBase = declarative_base(bind=discord_engine)
DiscordSession = scoped_session(sessionmaker(bind=discord_engine))
discord_session = DiscordSession()
class DiscordUser(DiscordBase):
	__tablename__ = 'discord'
	vk_id = Column(Integer, primary_key=True, autoincrement=True)
	id = Column(Integer)

	def __init__(self, vk_id, id):
		self.vk_id = vk_id
		self.id = id
	def __repr__(self):
		return f"<DiscordUser({self.vk_id}, {self.id})>"