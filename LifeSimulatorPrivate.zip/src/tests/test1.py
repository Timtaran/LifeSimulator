'''a = ''
for i in range(60):
	a += random.choice(for_token)
testUser = User(549204433, 0, 'Timtaran', 999999999, 99999999, 'start', a, 1, 1, 0)
session.add(testUser)
session.commit()
from aiohttp import web

async def handle(request):
	name = request.match_info.get('name', "Anonymous")
	text = "Hello, " + name
	return web.Response(text=text)

async def handle2(request):
	name = request.match_info.get('name', "???")
	id = request.match_info.get('id', "???")
	text = f'Hello, {name}, you id is {id}'
	return web.Response(text=text)
class post(web.View):
	async def get(self):
		return web.Response(text='Method not allowed')

	async def post(self):
		print(await self.request.json())
		return web.json_response({'rusult':'Sucess'})
app = web.Application()

app.add_routes([web.get('//', handle),
	web.get('//{name}', handle),
	web.get('//{name}/{id}', handle2),
				web.get('//{name}/', handle2),
				web.get('///', handle2),
				web.get('///{id}', handle2),
				web.view('/post', post)])'''
'''class MethodNotFounded(Exception):
	pass
class Test:
	def HelloWorld(self):
		self.tipization = {}
	def __getattr__(self, method: str):
		print(str(method))
		return ''
test = Test()
test.HelloWorld'''
import asyncio
from email.message import EmailMessage

import aiosmtplib
message = EmailMessage()
async def send_hello_world():
	message = """To: tentaranka@gmail.com
	From: blajeten@gmail.com
	Subject: Hello World!

	Sent via aiosmtplib
	"""
	await aiosmtplib.send(
		message,
		sender="blajeten@gmail.com",
		recipients=["tentaranka@gmail.com"],
		hostname="smtp.gmail.com",
		port=587,
		start_tls=True,
		#use_tls=True#,
		password='f4sm163513lfd.198'
	)
	'''await aiosmtplib.send(
		message,
		hostname="smtp.gmail.com",
		port=465,
		username="blajeten@gmail.com",
		password="T6b7&^73c78dv77Nyu",
		recipients=['tentaranka@gmail.com']
)'''

loop = asyncio.get_event_loop()
loop.run_until_complete(send_hello_world())