from aiohttp import web
class post(web.View):
	async def get(self):
		return web.Response(text='Method not allowed')

	async def post(self):
		print(await self.request.json())
		return web.json_response({'rusult':'Sucess'})
app = web.Application()

app.add_routes([web.view('/post', post)])