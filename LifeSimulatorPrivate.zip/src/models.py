###AND RULES###
from typing import List, Optional
from pydantic import BaseModel
from vkbottle.dispatch.rules.bot import ABCMessageRule
class usercheck(ABCMessageRule):
	async def check(self, message):
		if message.from_id == 549204433:
			return True
		return False

class start_user(BaseModel):
	id: int
	uid: int
	FullName: str
	nick: str
	location: str
