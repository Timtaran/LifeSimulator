import random
from src.vk.help import for_token
from sqlalchemy import Column, Integer, String,create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, scoped_session
engine = create_engine('postgresql://postgres:%||%\_/0296itTvG@127.0.0.1:5432/users', echo=False) #vk engine
#engine = create_engine('sqlite:///database.sqlite3', echo=False)
Base = declarative_base(bind=engine)
Session = scoped_session(sessionmaker(bind=engine))
session = Session()
class User(Base):
	__tablename__ = 'users'
	id = Column(Integer, primary_key=True, autoincrement=True)
	uid = Column(Integer)
	nick = Column(String(10))
	balance = Column(Integer)
	level = Column(Integer)
	where_is = Column(Integer)
	token = Column(String)
	admin = Column(Integer)
	moderator = Column(Integer)
	donate = Column(Integer)
	keyboard_type = Column(String)
	ban = Column(Integer)
	story = Column(Integer)
	bot_stopped = Column(Integer)
	FL_name = Column(String)
	ref = Column(Integer)

	def __init__(self, id, uid, nick, balance, level, where, token, admin, moderator, donate, FL_name):
		self.id = id
		self.uid = uid
		self.nick = nick
		self.balance = balance
		self.level = level
		self.where_is = where
		self.token = token
		self.admin = admin
		self.moderator = moderator
		self.donate = donate
		self.keyboard_type = 'Default'
		self.ban = 0
		self.story=0
		self.bot_stopped=0
		self.FL_name = FL_name
		self.ref = 0
	def __repr__(self):
		return f"<User({self.id}, {self.uid}, '{self.nick}', {self.balance}, {self.level}, '{self.where_is}', '{self.token}', {self.admin}, {self.moderator}, {self.donate}, '{self.keyboard_type}', {self.ban}, {self.story}, {self.bot_stopped}, {self.FL_name}, {self.ref})>"