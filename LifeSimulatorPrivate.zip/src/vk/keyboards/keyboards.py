from vkbottle import Keyboard, Text, Callback, KeyboardButtonColor
keyboard_set = (
    Keyboard(one_time=False)
    .add(Text("Callback кнопки", payload={"set": "callback"}))
    .add(Text("Обычные кнопки", payload={"set": "default"}))
    .get_json()
)
start = (
    Keyboard(one_time=False)
    .add(Text("Курьер", payload={"gamemode": "1"}))
    .get_json()
)
async def stop(json):
    return (
    Keyboard(one_time=False)
    .add(Text('Продолжить', payload=json), color=KeyboardButtonColor.POSITIVE)
    .get_json()
)
def sync_stop(json):
    return (
    Keyboard(one_time=False)
    .add(Text('Продолжить', payload=json), color=KeyboardButtonColor.POSITIVE)
    .get_json()
)
story1 = (
    Keyboard(one_time=False)
    .add(Text("Да", payload={"police1": "1"}), color=KeyboardButtonColor.POSITIVE)
    .add(Text("Нет", payload={"police1": "0"}), color=KeyboardButtonColor.NEGATIVE)
    .get_json()
)
menu1 = (Keyboard(one_time=False)
    .add(Text("пусто", payload={"police1": "1"}), color=KeyboardButtonColor.POSITIVE)
    .get_json())