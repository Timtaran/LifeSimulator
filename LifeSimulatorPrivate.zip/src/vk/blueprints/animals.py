from src.vk.files.animals import cats
from src.vk.help import get_data
from vkbottle.tools import PhotoMessageUploader
import random
from vkbottle.bot import Message, Blueprint
#part of neuronets.py
bot = Blueprint(name='animmals')
bot.labeler.vbml_ignore_case = True
@bot.on.chat_message(text=['кошка', 'кот', "котик", 'котенок', 'котёнок', 'котики', 'cat', 'cats'])
async def cat(message: Message):
	PhotoUploader = PhotoMessageUploader(message.ctx_api, generate_attachment_strings=True)
	photo = await PhotoUploader.upload(await get_data('https://thiscatdoesnotexist.com/'))
	await message.answer('Котик!', attachment=[random.choice(cats), photo])
@bot.on.chat_message(text=['лошадь', 'horse'])
async def thishorsesondoesnotexist(message: Message):
	PhotoUploader = PhotoMessageUploader(message.ctx_api, generate_attachment_strings=True)
	photo = await PhotoUploader.upload(await get_data('https://thishorsedoesnotexist.com/'))
	await message.answer('Котик!', attachment=[photo])