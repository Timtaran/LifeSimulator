from vkbottle.bot import Blueprint
from src.vk.dev_mode import dev_mode as dev
from vkbottle.tools import PhotoMessageUploader, VideoUploader
bot = Blueprint()
from vkbottle.bot import Message

@bot.on.message(text='test')
async def handler(message: Message):
	pu = PhotoMessageUploader(message.ctx_api, generate_attachment_strings=True)
	vu = VideoUploader(message.ctx_api, generate_attachment_strings=True)
	await dev(message, 'Uploading Image')
	await dev(message, 'Sending Image')
	#await message.answer(attachment=photo)
	await dev(message, 'Ching Cheng Hanji Time')
	await message.answer(attachment=['video166363579_456239163', photo])