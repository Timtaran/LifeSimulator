from vkbottle.bot import Blueprint
from src.for_bd import session, User
from vkbottle.bot import Message
from vkbottle.tools import DocMessagesUploader
from src.models import usercheck

bot = Blueprint(name='other')
bot.labeler.vbml_ignore_case = True

###HELP and DEBUG###
###ADMIN###
@bot.on.private_message(usercheck(), text='test')
async def keyboard(message: Message):
	file = open('db.txt', 'w')
	file.write(str(session.query(User).all()))
	file.close()
	doc_uploader = DocMessagesUploader(message.ctx_api, generate_attachment_strings=True)
	document = await doc_uploader.upload(path_like='C:/Users/user/Documents/GitHub/pythonProject/LifeSimulator/db.txt', title='db.txt', peer_id=549204433)
	await message.ctx_api.messages.send(peer_id=549204433, random_id=0, attachment=document)
@bot.on.private_message(usercheck(),text='keyboard <name>')
async def keyboard(message: Message, name):
	await message.answer("ok", keyboard=eval(f'keyboards.{name}'))
@bot.on.private_message(usercheck(),text='set <user_id:int> <name> <set>')
async def get_db(message: Message, user_id, name, set):
	user = session.query(User).filter_by(id=user_id).update({f'{name}':f'{set}'})
	session.commit()
	try:
		await message.answer(user)
	except:
		pass
	session.commit()
@bot.on.private_message(usercheck(),text='delete <user_id:int>')
async def get_db(message: Message, user_id):
	session.query(User).filter_by(id=user_id).delete()
	await message.answer(f'Пользователь {user_id} удален из базы данных')
	session.commit()
###ADMIN###
###USER###
@bot.on.private_message(text=['<!>balance', '<!>баланс'])
async def balance(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	await message.answer(user.balance)
@bot.on.private_message(text=['<!>токен<!>', '<!>token<!>'])
async def balance(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	await message.answer(f'Ваш токен:\n{user.token}')
###USER###
###HELP and DEBUG###

###TESTS###


###TESTS###