from vkbottle.bot import Blueprint, Message
from src.vk.help import get_data
from vkbottle.tools import PhotoMessageUploader
bot = Blueprint(name='neuronets')
bot.labeler.vbml_ignore_case = True
@bot.on.chat_message(text=['лицо', 'head', 'человек', 'person'])
async def thispersondoesnotexist(message:Message):
	PhotoUploader = PhotoMessageUploader(message.ctx_api, generate_attachment_strings=True)
	await message.answer(attachment=
		await PhotoUploader.upload(
			await get_data('https://thispersondoesnotexist.com/image')))
	'''async with aiohttp.ClientSession() as session:
		url = "https://thispersondoesnotexist.com/"
		async with session.get(url) as resp:
			if resp.status == 200:
				await message.answer(attachment=
									 await PhotoUploader.upload(
										 await resp.read()))'''
@bot.on.chat_message(text=['art', 'арт'])
async def thisartworksondoesnotexist(message:Message):
	PhotoUploader = PhotoMessageUploader(message.ctx_api, generate_attachment_strings=True)
	await message.answer(attachment=
		await PhotoUploader.upload(
			await get_data('https://thisartworkdoesnotexist.com/')))