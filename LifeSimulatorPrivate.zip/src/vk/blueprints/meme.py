from vkbottle.tools import PhotoMessageUploader
from vkbottle.bot import Message, Blueprint
bot = Blueprint(name='memes')
bot.labeler.vbml_ignore_case = True
@bot.on.message(text=['<!>ну давай ещё раз обидь это же так легко<!>', '<!>ещё раз обидь<!>', '<!>еще раз обидь<!>'])
async def meme1(message:Message):
	PhotoUploader = PhotoMessageUploader(message.ctx_api, generate_attachment_strings=True)
	await message.answer(attachment=await PhotoUploader.upload('ну давай ещё раз обидь это же так легко а сказать доброе слово это тяжело. Понятно потому что у тебя натура злая потому что ты сам злой. Ты не можешь выражать добро к другим .jpg'))