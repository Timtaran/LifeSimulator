from src.for_bd import session, User
from src.vk.dev_mode import where
from vkbottle.bot import Message, Blueprint
from src.vk.keyboards.keyboards import story1, stop, menu1
import time
import asyncio


async def st1(message):
	await message.answer('-Эх, как хочется узнать что в этой коробке.')
	await asyncio.sleep(7)
	await message.answer('-ЛОВИ ЕГО!')
	await asyncio.sleep(3)
	await message.answer('-ЭЭЭЭЭЭЭ, вы чего?\n-Это ты, чего.\n-А че такое то?\n-Объясни ему.')
	await asyncio.sleep(2.1)
	await message.answer('-Вчера ночью мы боролись с накркотиками и напалили на завод по их производству. Они успели передать курьеру заказ. Мы повязали главных, они дали нам твои паспортные данные.\n-Я ничего не делал!')
	await asyncio.sleep(13)
	await message.answer('-Говоришь ничего не делал? Что в коробке? Почему от туда слышны какие-то звуки?\n-Я не знаю.\n-Вскрываем коробку!')
	await asyncio.sleep(13)
	await message.answer('-И что это?\n-Это... это... бомба,?')
	await asyncio.sleep(1)
	await message.answer('Робот: 7-6-5')
	await asyncio.sleep(0.5)
	await message.answer('Вот ***(Хороним фразу которая тут была(прикрепленная аудиозапись))... БЕЖИМ!', attachment='audio549204433_456239041')#<div class="audio_page_player2 _audio_page_player _audio_row clear_fix" data-audio="[456239041,549204433,"","Astronomia 2K19","Stephan F",190,0,0,"",0,2,"","[]","58f78a5d59d03f3811//605808967d71abb0e6/e5d174b6492dbcb846//be314e1282ef58c7f3/4d0f7cbc253e3ec2e4","",{"duration":190,"content_id":"549204433_456239041","puid22":11,"account_age_type":2,"_SITEID":276,"vk_id":549204433,"ver":251116},"","","",false,"55cf0cfeMy945l1knrpuFu4Ws98lsXUP1jAl-UR4QCCY0fB5mLw7Jwg",0,0,true,"",false]" style="width: 795px; height: 59px;">
	await message.answer('-АААААААААА! (несколько человек)')
	await asyncio.sleep(6)
	await message.answer('-Никто не пострадал?\n-Нет (несколько человек через разное время)')
	await asyncio.sleep(3)
	await message.answer('Потащили его!')
	await message.answer('Сюжет приостановлен, так как одновременно может проходить сюжет маленькое количество людей, что-бы продолжить нажмите кнопку.',
						 keyboard=await stop({'continue':"1"}))
async def st11(message, user):
	await message.answer('Вы подъехали к дому, идете к нему, поднимаетесь.')
	await asyncio.sleep(30)
	await message.answer('-Ты будешь приманкой.')
	await asyncio.sleep(3)
	await message.answer('Звонок в дверь.')
	await asyncio.sleep(3)
	await message.answer('-Здравствуйте, ваша посылка!')
	await asyncio.sleep(0.2)
	await message.answer('-Ты че *** ***(вы все сами знаете) меня хотел? Мне посылку еще вчера доставили!')
	await asyncio.sleep(3)
	await message.answer('Вас вырубили, последнии слова что вы слышали:\n-Вя....его!\n-Ск...я, с..... т.......века вырубили, и .....о ...ет к..вь, ад.е...(почти одновременно, на фоне шум.)\n\n\nВозвращайтесь через 10 минут', keyboard=await stop({"police": "111"}))
	user.bot_stopped = round(time.time()) + 600
	session.commit()
from src.vk.help import where_is
bot = Blueprint(name='story mode')
bot.labeler.vbml_ignore_case = True
@bot.on.private_message(payload={"gamemode": "1"})
async def s1_start(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	if user.where_is == 'start':
		user.where_is = '1'
		session.commit()
		await message.answer(f'Вы - курьер, ваша локация: {where_is[str(user.where_is)]}')
		await where(message, user)
		bot.loop.create_task(st1(message))
@bot.on.private_message(payload={'continue':"1"})
async def s1(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	if user.where_is == '1':
		await message.answer('-Почему ты относил посылку с неизвестным тебе товаром?\n-Я всегда относил такие посылки, таких же размеров, примерно одинакового веса в один и тот же дом.\n-Какой адрес этого дома?\n-Проспект Ленина 18 подъезд 1 квартира 12(улица настоящая, остальное на рандом написано)\n-Хорошо, мы пойдем туда, ты с нами?',
							 keyboard=story1)

@bot.on.private_message(payload={"police1": "1"})
async def s11(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	if user.where_is == '1':
		await message.answer('Вы поехали с полицией.', keyboard=await stop({"police": "11"}))
@bot.on.private_message(payload={"police1": "0"})
async def s12(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	if user.where_is == '1':
		await message.answer('Вы не поехали с полицией.', keyboard=await stop({"police": "12"}))
@bot.on.private_message(payload={"police": "11"})
async def s11(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	if user.where_is == '1':
		user.where_is = '11'
		session.commit()
		bot.loop.create_task(st11(message, user))
@bot.on.private_message(payload={"police": "111"})
async def s11(message: Message):
	user = session.query(User).filter_by(id=message.from_id).first()
	if user.where_is == '11':
		if user.bot_stopped < time.time():
			await message.answer('-Да, мы сделали это, даааа!\nЧтттто ппроизошло...\n-Ты чуть не умер, но мы смогли тебя спасти.\nВас отвезли до дома.', keyboard=menu1)
		else:
			await message.answer('10 минут еще не прошло)')