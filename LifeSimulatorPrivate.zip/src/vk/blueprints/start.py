from vkbottle.bot import Blueprint
import random
from src.for_bd import session, User
from src.vk.dev_mode import dev_mode
from src.config import config
from src.models import start_user
from src.vk.help import for_token, where_is
from src.vk.keyboards.keyboards import start

bot = Blueprint(name='reg')
from vkbottle import BaseMiddleware
from vkbottle.bot import Message
class RegistrationMiddleware(BaseMiddleware):
	async def pre(self, message: Message):
		if message.peer_id < 2000000000:
			if session.query(User).filter_by(id=message.from_id).first() == None:
				a = ''
				for i in range(60):
					a += random.choice(for_token)
				users = 1
				for _ in session.query(User).all():
					users+=1
				FL = (await message.ctx_api.users.get(user_ids=[message.from_id]))[0]
				FL = FL.first_name + ' ' + FL.last_name
				testUser = User(message.from_id, users, 'Игрок', 0, 0, 'start', a, 0, 0, 0, FL)
				session.add(testUser)
				session.commit()
				external_data = {'id': message.from_id, 'uid': users, 'FullName':FL, 'nick':'Игрок', 'location':where_is['start']}
				startUser = start_user(**external_data)
				await dev_mode(message, startUser)
				await message.answer(f'Вы зарегистрированны, ваш uid {users}')
				await message.answer('Используются обычные кнопки. (можно изменить)')
				await message.answer('Выберите персонажа', keyboard=start)
		return ''
class ReferalMiddleware(BaseMiddleware):
	async def pre(self, message: Message):
		if message.peer_id < 2000000000:
			if message.ref != None:
				user = session.query(User).filter_by(id=message.from_id).first()
				if int(message.ref) == message.from_id:
					await message.answer('Вот ты так зачем сделал...')
				else:
					if user.ref == 0 or user.ref == None:
						referal = session.query(User).filter_by(id=message.ref).first()
						if referal != None:
							await message.answer(f'Передай человеку, который тебя пригласил, что он ничего с тебя не получит) (зачислю тебе на баланс 1000 за то что по рефке перешел)([id{message.ref}|{referal.FL_name}])')
							await message.ctx_api.messages.send(peer_id=549204433, random_id=0, message='По твоей ссылке кто-то перешел, но ты ничего не получишь)')
							user.balance+=1000
							user.ref=message.ref
							session.commit()
						else:
							await message.answer('Ну как бы такого пользователя в боте, нет...')
bot.labeler.message_view.register_middleware(RegistrationMiddleware())
bot.labeler.message_view.register_middleware(ReferalMiddleware())