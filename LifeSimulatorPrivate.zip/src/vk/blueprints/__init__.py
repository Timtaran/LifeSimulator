from . import start, animals, story, other, neuronets, meme#, uploaders

bps = [start.bot, animals.bot, story.bot, other.bot, neuronets.bot, meme.bot]