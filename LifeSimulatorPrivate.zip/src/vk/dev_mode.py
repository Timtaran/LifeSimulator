from src.vk.help import where_is
async def dev_mode(message, info):
	await message.ctx_api.messages.send(chat_id=2, random_id=0, message=f'[[id{message.from_id}|debug]] {info}')
async def where(message, user):
	await message.ctx_api.messages.send(chat_id=2, random_id=0, message=f'[debug, [id{message.from_id}|{user.nick}]] Локация пользователя - {user.where_is}')
async def where_i(message, user):
	await message.answer(f'Вы находитесь в \n{where_is[str(user.where_is)]}')