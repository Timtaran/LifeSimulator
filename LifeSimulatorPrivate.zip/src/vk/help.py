from vkbottle.http import AiohttpClient
from io import BytesIO
"""
bot.py -             if event['updates'] != []:
                logger.debug(f"New event was received: {event}") 63-64
bot_polling.py - #logger.debug("Making long request to get event with longpoll...") 31
api.py - #logger.debug("API response was validated") 79
logger.debug("API request was validated") 87
vkbottle.dispatch.views.bot.message:handle_event -             if debug: 52-53
                logger.debug("Handler {} returned {}".format(handler, result))
"""
for_token = ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '\\', '|', 'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', ':', ';', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', '<', '>', '?', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '_', '-', '+', '=', 'q', 'w', 'e', 'r', 't', 'y', 'u', 'i', 'o', 'p', 'a', 's', 'd', 'f', 'g', 'h', 'j', 'k', 'l', 'z', 'x', 'c', 'v', 'b', 'n', 'm']
where_is = {
	'start':'Выбор персонажа.',
	"1": 'Курьер, начало',
	"11": 'Курьер, допрос 1 - 1',
	"10": 'Курьер, допрос 1 - 0'
}
ban = {
	'1':'получен',
	'0':'не получен'
}
async def get_data(link, client_session=None):
	http = AiohttpClient(session=client_session)
	data = await http. request_content("GET", link)
	if not client_session:
		await http.close()
	return BytesIO(data)